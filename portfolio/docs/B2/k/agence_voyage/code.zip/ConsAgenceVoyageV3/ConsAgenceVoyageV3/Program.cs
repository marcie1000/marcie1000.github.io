﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Voyage;

namespace Voyage
{
    class Program
    {
        static public void initDestinations(ref string [] nomsDests)
        {
            // Destinations
            nomsDests[0] = "Grèce";
            nomsDests[1] = "Italie";
            nomsDests[2] = "Crête";
            nomsDests[3] = "Rhodes";
            nomsDests[4] = "Turquie";
            nomsDests[5] = "Égypte";
            nomsDests[6] = "Canarie";
        }

        static public void initDestinations(ref string[] nomsDests, string add)
        {
            // Destinations
            nomsDests[0] = "Grèce";
            nomsDests[1] = "Italie";
            nomsDests[2] = "Crête";
            nomsDests[3] = "Rhodes";
            nomsDests[4] = "Turquie";
            nomsDests[5] = "Égypte";
            nomsDests[6] = "Canarie";

            for (int i = 0; i < 7; i++)
                nomsDests[i] += add;
        }
        static public void initDestinations2(ref string[] nomsDests)
        {
            // Destinations
            nomsDests[0] = "Grèce2";
            nomsDests[1] = "Italie2";
            nomsDests[2] = "Crête2";
            nomsDests[3] = "Rhodes2";
            nomsDests[4] = "Turquie2";
            nomsDests[5] = "Egypte2";
            nomsDests[6] = "Canarie2";
        }

        static public void initAgences(ref string [] nomsAgences)
        {
            // Agences
            nomsAgences[0] = "Nlle Frontiere";
            nomsAgences[1] = "FRAM";
            nomsAgences[2] = "Rev'Evasion";
            nomsAgences[3] = "Starter";
        }

        static public void initAgences(ref string[] nomsAgences, string add)
        {
            // Agences
            nomsAgences[0] = "Nlle Frontiere";
            nomsAgences[1] = "FRAM";
            nomsAgences[2] = "Rev'Evasion";
            nomsAgences[3] = "Starter";

            for (int i = 0; i < 4; i++)
                nomsAgences[i] += add;
        }

        static public void initAgences2(ref string[] nomsAgences)
        {
            // Agences
            nomsAgences[0] = "Nlle Frontiere2";
            nomsAgences[1] = "FRAM2";
            nomsAgences[2] = "Rev'Evasion2";
            nomsAgences[3] = "Starter2";
        }
        static void Main(string[] args)
        {

            string[] nomsDests = new string[7];
            string[] nomsAgences = new string[4];
            int[,] prix = new int[4, 7];

            initDestinations(ref nomsDests);
            initAgences(ref nomsAgences);
            Voyage unVoyage = new Voyage(nomsDests, nomsAgences);
            //unVoyage.saisieDests();
            //unVoyage.saisieAgences();
            unVoyage.generationPrix();
            unVoyage.affAgences();
            unVoyage.affDestinations();
            unVoyage.affPrix();
            unVoyage.affDestLaPlusChere();
            unVoyage.affAgenceLaMoinsChere();
            string agence = "", dest = "";
            int somme = 200;
            if (unVoyage.budgetVacances(somme, ref agence, ref dest))
                Console.WriteLine("Pour une somme de " + somme + ", vous pouvez partir en " + dest + " avec " + agence);
            else
                Console.WriteLine("Pour une somme de " + somme + ", vous ne pouvez pas partir en vacances.");
            Console.ReadKey();


            initDestinations2(ref nomsDests);
            initAgences2(ref nomsAgences);
            
            Voyage unVoyage2 = new Voyage(nomsDests, nomsAgences);
            //unVoyage2.saisieDests(nomsDests);
            //unVoyage2.saisieAgences(nomsAgences);
            unVoyage2.generationPrix();
            unVoyage2.affAgences();
            unVoyage2.affDestinations();
            unVoyage2.affPrix();
            unVoyage2.affDestLaPlusChere();
            unVoyage2.affAgenceLaMoinsChere();
            agence = ""; 
            dest = "";
            somme = 200;
            if (unVoyage.budgetVacances(somme, ref agence, ref dest))
                Console.WriteLine("Pour une somme de " + somme + ", vous pouvez partir en " + dest + " avec " + agence);
            else
                Console.WriteLine("Pour une somme de " + somme + ", vous ne pouvez pas partir en vacances.");
            Console.ReadKey();

            initDestinations(ref nomsDests, "K");
            initAgences(ref nomsAgences, "K");

            Voyage unVoyage3 = new Voyage(nomsDests, nomsAgences);
            //unVoyage3.saisieDests(nomsDests);
            //unVoyage3.saisieAgences(nomsAgences);
            unVoyage3.generationPrix();
            unVoyage3.affAgences();
            unVoyage3.affDestinations();
            unVoyage3.affPrix();
            unVoyage3.affDestLaPlusChere();
            unVoyage3.affAgenceLaMoinsChere();
            agence = "";
            dest = "";
            somme = 200;
            if (unVoyage.budgetVacances(somme, ref agence, ref dest))
                Console.WriteLine("Pour une somme de " + somme + ", vous pouvez partir en " + dest + " avec " + agence);
            else
                Console.WriteLine("Pour une somme de " + somme + ", vous ne pouvez pas partir en vacances.");
            Console.ReadKey();
        }
    }
}
