﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClVoyage;

namespace ConsVoyageV2
{
    class Program
    {
        static void Main(string[] args)
        {
            Voyage unVoyage = new Voyage();
            Voyage unVoyage2 = new Voyage();

            unVoyage.saisieDests();
            unVoyage2.saisieDests();
            unVoyage.saisieAgences();
            unVoyage.generationPrix();
            unVoyage.affAgences();
            unVoyage.affDestinations();
            unVoyage.affPrix();
            unVoyage.affDestLaPlusChere();
            unVoyage.affAgenceLaMoinsChere();
            string agence = "", dest = "";
            int somme = 200;
            if (unVoyage.budgetVacances(somme, ref agence, ref dest))
                Console.WriteLine("Pour une somme de " + somme + ", vous pouvez partir en " + dest + " avec " + agence);
            else
                Console.WriteLine("Pour une somme de " + somme + ", vous ne pouvez pas partir en vacances.");
            Console.ReadKey();
        }
    }
}
