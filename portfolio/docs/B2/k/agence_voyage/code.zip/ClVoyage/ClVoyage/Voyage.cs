﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClVoyage
{
    public class Voyage
    {
        /*
         * Ma classe doit être anonyme;
         * Ma classe ne doit pas contenir de données
         */

        private string[] nomsDests = new string[7];
        private string[] nomsAgences = new string[4];
        private int[,] prix = new int[4, 7];

        public Voyage() // Constructeur
        {

        }

        public void saisieDests()
        {
            // Destinations
            nomsDests[0] = "Grèce";
            nomsDests[1] = "Italie";
            nomsDests[2] = "Crête";
            nomsDests[3] = "Rhodes";
            nomsDests[4] = "Turquie";
            nomsDests[5] = "Egypte";
            nomsDests[6] = "Canarie";
        }

        public void saisieAgences()
        {
            // Agences
            nomsAgences[0] = "Nlle Frontiere";
            nomsAgences[1] = "FRAM";
            nomsAgences[2] = "Rev'Evasion";
            nomsAgences[3] = "Starter";
        }

        public void generationPrix()
        {
            Random rnd = new Random(); // génère un nb aléatoire
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    prix[i, j] = rnd.Next(80, 1000);
                }
            }
        }

        public void affPrix()
        {

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    Console.Write(prix[i, j] + " ");
                }
                Console.WriteLine();
            }
        }

        public void affDestinations()
        {
            Console.Write("Liste des destinations : \n");
            for (int i = 0; i < 7; i++)
                Console.Write(nomsDests[i] + " | ");
            Console.WriteLine();
        }

        public void affAgences()
        {
            Console.Write("Liste des agences : \n");
            for (int i = 0; i < 4; i++)
                Console.Write(nomsAgences[i] + " | ");
            Console.WriteLine();
        }

        public void affDestLaPlusChere()
        {
            int max = 0, imax = 0, jmax = 0;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    if (prix[i, j] > max)
                    {
                        max = prix[i, j];
                        imax = i;
                        jmax = j;
                    }
                }
            }
            Console.WriteLine("Agence/destination la plus chère : " + nomsAgences[imax] + " / " +
                nomsDests[jmax] + " au prix de " + max + " EUR.");
        }

        public void affAgenceLaMoinsChere()
        {
            int cumulMin = 1000 * 7;
            int cumulAgence = 0;
            int imin = 0;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    cumulAgence += prix[i, j];
                }

                if (cumulAgence < cumulMin)
                {
                    cumulMin = cumulAgence;
                    imin = i;
                }

                cumulAgence = 0;
            }
            Console.WriteLine("Agence la moins chère : " + nomsAgences[imin] + " (" + cumulMin + " EUR).\n");
        }
        public bool budgetVacances(int somme, ref string agence, ref string dest)
        {
            bool possible = false;
            int i = 0;
            int j = 0;
            while (i < 4 && !possible)
            {
                if (somme >= prix[i, j])
                {
                    possible = true;
                    agence = nomsAgences[i];
                    dest = nomsDests[j];
                }
                if (j == 6)
                {
                    j = 0;
                    i++;
                }
                else
                    j++;
            }

            return possible;
        }
    }
}
