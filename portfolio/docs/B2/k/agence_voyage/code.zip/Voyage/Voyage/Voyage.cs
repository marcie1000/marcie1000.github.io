﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Voyage
{
    public class Voyage
    {
        /*
         * Ma classe doit être anonyme;
         * Ma classe ne doit pas contenir de données
         */

        private string[] nomsDests = new string[7];
        private string[] nomsAgences = new string[4];
        private int[,] prix = new int[4, 7];

        public Voyage() // Constructeur
        {

        }

        public Voyage(string[] nomsDests, string[] nomsAgences) // Constructeur
        {
            saisieDests(nomsDests);
            saisieAgences(nomsAgences);
        }

        public void saisieDests()
        {
            // Destinations
            nomsDests[0] = "Adélia";
            nomsDests[1] = "Adélia";
            nomsDests[2] = "Adélia";
            nomsDests[3] = "Adélia";
            nomsDests[4] = "Adélia";
            nomsDests[5] = "Adélia";
            nomsDests[6] = "Adélia";
        }

        public void saisieDests(string [] nomsDests)
        {
            for(int i = 0; i < 7; i++)
            {
                // de la classe | du main en paramètre
                this.nomsDests[i] = nomsDests[i];
            }
        }

        public void saisieAgences()
        {
            // Agences
            nomsAgences[0] = "Adélia";
            nomsAgences[1] = "Adélia";
            nomsAgences[2] = "Adélia";
            nomsAgences[3] = "Adélia";
        }

        public void saisieAgences(string [] nomsAgences)
        {
            for(int i = 0; i < 4; i++)
            {
                this.nomsAgences[i] = nomsAgences[i];
            }
        }

        public void generationPrix()
        {
            Random rnd = new Random(); // génère un nb aléatoire
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    prix[i, j] = rnd.Next(80, 1000);
                }
            }
        }

        public void affPrix()
        {

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    Console.Write(prix[i, j] + " ");
                }
                Console.WriteLine();
            }
        }

        public void affDestinations()
        {
            Console.Write("Liste des destinations : \n");
            for (int i = 0; i < 7; i++)
                Console.Write(nomsDests[i] + " | ");
            Console.WriteLine();
        }

        public void affAgences()
        {
            Console.Write("Liste des agences : \n");
            for (int i = 0; i < 4; i++)
                Console.Write(this.nomsAgences[i] + " | ");
            Console.WriteLine();
        }

        public void affDestLaPlusChere()
        {
            int max = 0, imax = 0, jmax = 0;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    if (prix[i, j] > max)
                    {
                        max = prix[i, j];
                        imax = i;
                        jmax = j;
                    }
                }
            }
            Console.WriteLine("Agence/destination la plus chère : " + nomsAgences[imax] + " / " +
                nomsDests[jmax] + " au prix de " + max + " EUR.");
        }

        public void affAgenceLaMoinsChere()
        {
            int cumulMin = 1000 * 7;
            int cumulAgence = 0;
            int imin = 0;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    cumulAgence += prix[i, j];
                }

                if (cumulAgence < cumulMin)
                {
                    cumulMin = cumulAgence;
                    imin = i;
                }

                cumulAgence = 0;
            }
            Console.WriteLine("Agence la moins chère : " + nomsAgences[imin] + " (" + cumulMin + " EUR).\n");
        }
        public bool budgetVacances(int somme, ref string agence, ref string dest)
        {
            bool possible = false;
            int i = 0;
            int j = 0;
            while (i < 4 && !possible)
            {
                if (somme >= prix[i, j])
                {
                    possible = true;
                    agence = nomsAgences[i];
                    dest = nomsDests[j];
                }
                if (j == 6)
                {
                    j = 0;
                    i++;
                }
                else
                    j++;
            }

            return possible;
        }
    }

}
