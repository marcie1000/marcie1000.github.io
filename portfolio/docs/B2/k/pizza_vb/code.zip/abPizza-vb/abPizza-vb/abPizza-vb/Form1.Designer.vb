﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gpbTaille = New System.Windows.Forms.GroupBox()
        Me.rdbGrande = New System.Windows.Forms.RadioButton()
        Me.rdbMoyenne = New System.Windows.Forms.RadioButton()
        Me.rdbPetite = New System.Windows.Forms.RadioButton()
        Me.cmdAchat = New System.Windows.Forms.Button()
        Me.gpbIngredients = New System.Windows.Forms.GroupBox()
        Me.chkTomates = New System.Windows.Forms.CheckBox()
        Me.chkPoivrons = New System.Windows.Forms.CheckBox()
        Me.chkOignons = New System.Windows.Forms.CheckBox()
        Me.chkOlives = New System.Windows.Forms.CheckBox()
        Me.chkChampignon = New System.Windows.Forms.CheckBox()
        Me.chkFromage = New System.Windows.Forms.CheckBox()
        Me.gpbCroute = New System.Windows.Forms.GroupBox()
        Me.rdbEpaisse = New System.Windows.Forms.RadioButton()
        Me.rdbFine = New System.Windows.Forms.RadioButton()
        Me.rdbSurPlace = New System.Windows.Forms.RadioButton()
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.cmdInitialisation = New System.Windows.Forms.Button()
        Me.rdbAEmporter = New System.Windows.Forms.RadioButton()
        Me.lblLimitIngr = New System.Windows.Forms.Label()
        Me.clbSupplements = New System.Windows.Forms.CheckedListBox()
        Me.gpbSupplements = New System.Windows.Forms.GroupBox()
        Me.gpbTaille.SuspendLayout()
        Me.gpbIngredients.SuspendLayout()
        Me.gpbCroute.SuspendLayout()
        Me.gpbSupplements.SuspendLayout()
        Me.SuspendLayout()
        '
        'gpbTaille
        '
        Me.gpbTaille.Controls.Add(Me.rdbGrande)
        Me.gpbTaille.Controls.Add(Me.rdbMoyenne)
        Me.gpbTaille.Controls.Add(Me.rdbPetite)
        Me.gpbTaille.Location = New System.Drawing.Point(73, 53)
        Me.gpbTaille.Name = "gpbTaille"
        Me.gpbTaille.Size = New System.Drawing.Size(230, 183)
        Me.gpbTaille.TabIndex = 1
        Me.gpbTaille.TabStop = False
        Me.gpbTaille.Text = "Taille"
        '
        'rdbGrande
        '
        Me.rdbGrande.AutoSize = True
        Me.rdbGrande.Checked = True
        Me.rdbGrande.Location = New System.Drawing.Point(13, 111)
        Me.rdbGrande.Name = "rdbGrande"
        Me.rdbGrande.Size = New System.Drawing.Size(77, 21)
        Me.rdbGrande.TabIndex = 2
        Me.rdbGrande.TabStop = True
        Me.rdbGrande.Text = "Grande"
        Me.rdbGrande.UseVisualStyleBackColor = True
        '
        'rdbMoyenne
        '
        Me.rdbMoyenne.AutoSize = True
        Me.rdbMoyenne.Location = New System.Drawing.Point(13, 74)
        Me.rdbMoyenne.Name = "rdbMoyenne"
        Me.rdbMoyenne.Size = New System.Drawing.Size(87, 21)
        Me.rdbMoyenne.TabIndex = 1
        Me.rdbMoyenne.Text = "Moyenne"
        Me.rdbMoyenne.UseVisualStyleBackColor = True
        '
        'rdbPetite
        '
        Me.rdbPetite.AutoSize = True
        Me.rdbPetite.Location = New System.Drawing.Point(13, 34)
        Me.rdbPetite.Name = "rdbPetite"
        Me.rdbPetite.Size = New System.Drawing.Size(65, 21)
        Me.rdbPetite.TabIndex = 0
        Me.rdbPetite.Text = "Petite"
        Me.rdbPetite.UseVisualStyleBackColor = True
        '
        'cmdAchat
        '
        Me.cmdAchat.Location = New System.Drawing.Point(73, 428)
        Me.cmdAchat.Name = "cmdAchat"
        Me.cmdAchat.Size = New System.Drawing.Size(196, 29)
        Me.cmdAchat.TabIndex = 2
        Me.cmdAchat.Text = "Achat Pizza"
        Me.cmdAchat.UseVisualStyleBackColor = True
        '
        'gpbIngredients
        '
        Me.gpbIngredients.Controls.Add(Me.chkTomates)
        Me.gpbIngredients.Controls.Add(Me.chkPoivrons)
        Me.gpbIngredients.Controls.Add(Me.chkOignons)
        Me.gpbIngredients.Controls.Add(Me.chkOlives)
        Me.gpbIngredients.Controls.Add(Me.chkChampignon)
        Me.gpbIngredients.Controls.Add(Me.chkFromage)
        Me.gpbIngredients.Location = New System.Drawing.Point(348, 53)
        Me.gpbIngredients.Name = "gpbIngredients"
        Me.gpbIngredients.Size = New System.Drawing.Size(372, 183)
        Me.gpbIngredients.TabIndex = 3
        Me.gpbIngredients.TabStop = False
        Me.gpbIngredients.Text = "Ingrédients"
        '
        'chkTomates
        '
        Me.chkTomates.AutoSize = True
        Me.chkTomates.Location = New System.Drawing.Point(185, 111)
        Me.chkTomates.Name = "chkTomates"
        Me.chkTomates.Size = New System.Drawing.Size(85, 21)
        Me.chkTomates.TabIndex = 5
        Me.chkTomates.Text = "Tomates"
        Me.chkTomates.UseVisualStyleBackColor = True
        '
        'chkPoivrons
        '
        Me.chkPoivrons.AutoSize = True
        Me.chkPoivrons.Location = New System.Drawing.Point(185, 74)
        Me.chkPoivrons.Name = "chkPoivrons"
        Me.chkPoivrons.Size = New System.Drawing.Size(85, 21)
        Me.chkPoivrons.TabIndex = 4
        Me.chkPoivrons.Text = "Poivrons"
        Me.chkPoivrons.UseVisualStyleBackColor = True
        '
        'chkOignons
        '
        Me.chkOignons.AutoSize = True
        Me.chkOignons.Location = New System.Drawing.Point(185, 35)
        Me.chkOignons.Name = "chkOignons"
        Me.chkOignons.Size = New System.Drawing.Size(83, 21)
        Me.chkOignons.TabIndex = 3
        Me.chkOignons.Text = "Oignons"
        Me.chkOignons.UseVisualStyleBackColor = True
        '
        'chkOlives
        '
        Me.chkOlives.AutoSize = True
        Me.chkOlives.Location = New System.Drawing.Point(26, 111)
        Me.chkOlives.Name = "chkOlives"
        Me.chkOlives.Size = New System.Drawing.Size(69, 21)
        Me.chkOlives.TabIndex = 2
        Me.chkOlives.Text = "Olives"
        Me.chkOlives.UseVisualStyleBackColor = True
        '
        'chkChampignon
        '
        Me.chkChampignon.AutoSize = True
        Me.chkChampignon.Location = New System.Drawing.Point(26, 74)
        Me.chkChampignon.Name = "chkChampignon"
        Me.chkChampignon.Size = New System.Drawing.Size(109, 21)
        Me.chkChampignon.TabIndex = 1
        Me.chkChampignon.Text = "Champignon"
        Me.chkChampignon.UseVisualStyleBackColor = True
        '
        'chkFromage
        '
        Me.chkFromage.AutoSize = True
        Me.chkFromage.Location = New System.Drawing.Point(26, 35)
        Me.chkFromage.Name = "chkFromage"
        Me.chkFromage.Size = New System.Drawing.Size(86, 21)
        Me.chkFromage.TabIndex = 0
        Me.chkFromage.Text = "Fromage"
        Me.chkFromage.UseVisualStyleBackColor = True
        '
        'gpbCroute
        '
        Me.gpbCroute.Controls.Add(Me.rdbEpaisse)
        Me.gpbCroute.Controls.Add(Me.rdbFine)
        Me.gpbCroute.Location = New System.Drawing.Point(73, 259)
        Me.gpbCroute.Name = "gpbCroute"
        Me.gpbCroute.Size = New System.Drawing.Size(230, 130)
        Me.gpbCroute.TabIndex = 4
        Me.gpbCroute.TabStop = False
        Me.gpbCroute.Text = "Croute"
        '
        'rdbEpaisse
        '
        Me.rdbEpaisse.AutoSize = True
        Me.rdbEpaisse.Checked = True
        Me.rdbEpaisse.Location = New System.Drawing.Point(13, 79)
        Me.rdbEpaisse.Name = "rdbEpaisse"
        Me.rdbEpaisse.Size = New System.Drawing.Size(79, 21)
        Me.rdbEpaisse.TabIndex = 1
        Me.rdbEpaisse.TabStop = True
        Me.rdbEpaisse.Text = "Épaisse"
        Me.rdbEpaisse.UseVisualStyleBackColor = True
        '
        'rdbFine
        '
        Me.rdbFine.AutoSize = True
        Me.rdbFine.Location = New System.Drawing.Point(13, 39)
        Me.rdbFine.Name = "rdbFine"
        Me.rdbFine.Size = New System.Drawing.Size(56, 21)
        Me.rdbFine.TabIndex = 0
        Me.rdbFine.Text = "Fine"
        Me.rdbFine.UseVisualStyleBackColor = True
        '
        'rdbSurPlace
        '
        Me.rdbSurPlace.AutoSize = True
        Me.rdbSurPlace.Checked = True
        Me.rdbSurPlace.Location = New System.Drawing.Point(348, 313)
        Me.rdbSurPlace.Name = "rdbSurPlace"
        Me.rdbSurPlace.Size = New System.Drawing.Size(89, 21)
        Me.rdbSurPlace.TabIndex = 5
        Me.rdbSurPlace.TabStop = True
        Me.rdbSurPlace.Text = "Sur place"
        Me.rdbSurPlace.UseVisualStyleBackColor = True
        '
        'cmdExit
        '
        Me.cmdExit.Location = New System.Drawing.Point(348, 428)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.Size = New System.Drawing.Size(174, 29)
        Me.cmdExit.TabIndex = 6
        Me.cmdExit.Text = "Exit"
        Me.cmdExit.UseVisualStyleBackColor = True
        '
        'cmdInitialisation
        '
        Me.cmdInitialisation.Location = New System.Drawing.Point(586, 428)
        Me.cmdInitialisation.Name = "cmdInitialisation"
        Me.cmdInitialisation.Size = New System.Drawing.Size(165, 29)
        Me.cmdInitialisation.TabIndex = 7
        Me.cmdInitialisation.Text = "Initialisation"
        Me.cmdInitialisation.UseVisualStyleBackColor = True
        '
        'rdbAEmporter
        '
        Me.rdbAEmporter.AutoSize = True
        Me.rdbAEmporter.Location = New System.Drawing.Point(515, 313)
        Me.rdbAEmporter.Name = "rdbAEmporter"
        Me.rdbAEmporter.Size = New System.Drawing.Size(99, 21)
        Me.rdbAEmporter.TabIndex = 8
        Me.rdbAEmporter.Text = "À emporter"
        Me.rdbAEmporter.UseVisualStyleBackColor = True
        '
        'lblLimitIngr
        '
        Me.lblLimitIngr.AutoSize = True
        Me.lblLimitIngr.ForeColor = System.Drawing.Color.Red
        Me.lblLimitIngr.Location = New System.Drawing.Point(345, 259)
        Me.lblLimitIngr.Name = "lblLimitIngr"
        Me.lblLimitIngr.Size = New System.Drawing.Size(358, 17)
        Me.lblLimitIngr.TabIndex = 6
        Me.lblLimitIngr.Text = "Vous ne pouvez choisir que 4 ingrédients au maximum !"
        Me.lblLimitIngr.Visible = False
        '
        'clbSupplements
        '
        Me.clbSupplements.FormattingEnabled = True
        Me.clbSupplements.Items.AddRange(New Object() {"Ananas", "Fromage de chèvre", "Anchois", "Crevettes"})
        Me.clbSupplements.Location = New System.Drawing.Point(18, 34)
        Me.clbSupplements.Name = "clbSupplements"
        Me.clbSupplements.Size = New System.Drawing.Size(289, 123)
        Me.clbSupplements.TabIndex = 9
        '
        'gpbSupplements
        '
        Me.gpbSupplements.Controls.Add(Me.clbSupplements)
        Me.gpbSupplements.Location = New System.Drawing.Point(755, 53)
        Me.gpbSupplements.Name = "gpbSupplements"
        Me.gpbSupplements.Size = New System.Drawing.Size(334, 183)
        Me.gpbSupplements.TabIndex = 10
        Me.gpbSupplements.TabStop = False
        Me.gpbSupplements.Text = "Suppléments"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1113, 561)
        Me.Controls.Add(Me.gpbSupplements)
        Me.Controls.Add(Me.lblLimitIngr)
        Me.Controls.Add(Me.rdbAEmporter)
        Me.Controls.Add(Me.cmdInitialisation)
        Me.Controls.Add(Me.cmdExit)
        Me.Controls.Add(Me.rdbSurPlace)
        Me.Controls.Add(Me.gpbCroute)
        Me.Controls.Add(Me.gpbIngredients)
        Me.Controls.Add(Me.cmdAchat)
        Me.Controls.Add(Me.gpbTaille)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.gpbTaille.ResumeLayout(False)
        Me.gpbTaille.PerformLayout()
        Me.gpbIngredients.ResumeLayout(False)
        Me.gpbIngredients.PerformLayout()
        Me.gpbCroute.ResumeLayout(False)
        Me.gpbCroute.PerformLayout()
        Me.gpbSupplements.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents gpbTaille As GroupBox
    Friend WithEvents rdbGrande As RadioButton
    Friend WithEvents rdbMoyenne As RadioButton
    Friend WithEvents rdbPetite As RadioButton
    Friend WithEvents cmdAchat As Button
    Friend WithEvents gpbIngredients As GroupBox
    Friend WithEvents chkTomates As CheckBox
    Friend WithEvents chkPoivrons As CheckBox
    Friend WithEvents chkOignons As CheckBox
    Friend WithEvents chkOlives As CheckBox
    Friend WithEvents chkChampignon As CheckBox
    Friend WithEvents chkFromage As CheckBox
    Friend WithEvents gpbCroute As GroupBox
    Friend WithEvents rdbEpaisse As RadioButton
    Friend WithEvents rdbFine As RadioButton
    Friend WithEvents rdbSurPlace As RadioButton
    Friend WithEvents cmdExit As Button
    Friend WithEvents cmdInitialisation As Button
    Friend WithEvents rdbAEmporter As RadioButton
    Friend WithEvents lblLimitIngr As Label
    Friend WithEvents clbSupplements As CheckedListBox
    Friend WithEvents gpbSupplements As GroupBox
End Class
