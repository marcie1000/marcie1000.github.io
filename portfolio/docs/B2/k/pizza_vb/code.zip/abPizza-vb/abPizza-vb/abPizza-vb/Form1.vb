﻿Public Class Form1
    Private Sub cmdBonjour_Click(sender As Object, e As EventArgs)
        MsgBox("Bonjour")
    End Sub

    Private Sub cmdAchat_Click(sender As Object, e As EventArgs) Handles cmdAchat.Click

        'Dim taille As String
        Dim i As Integer            ' Pour parcourir
        Dim radio As RadioButton
        Dim message As String = ""

        'If rdbGrande.Checked Then
        '    taille = rdbGrande.Text
        'ElseIf rdbMoyenne.Checked Then
        '    taille = rdbMoyenne.Text
        'Else
        '    taille = rdbPetite.Text
        'End If

        ' Parcourir les radiobuttons

        'For i = 0 To gpbTaille.Controls.Count - 1
        '    radio = gpbTaille.Controls(i)
        '    If radio.Checked Then
        '        taille = radio.Text
        '    End If
        'Next


        ' sur place / à emporter

        'Dim surplace As String
        If (rdbSurPlace.Checked) Then
            message = "Sur place" & vbCrLf
        Else
            message = "À emporter" & vbCrLf
        End If

        ' Taille

        i = 0
        radio = gpbTaille.Controls(i)

        ' Il y a 3 radiobuttons à tester, la boucle while s'arrêtera toute seule après le 3ème
        ' car il y en a forcément 1 de coché
        Do While radio.Checked = False
            i += 1
            radio = gpbTaille.Controls(i)
        Loop

        message = message & radio.Text & " pizza" & vbCrLf

        ' épaisseur croute

        If rdbEpaisse.Checked = True Then
            message = message & "Épaisse" & vbCrLf
        Else
            message = message & "Fine" & vbCrLf
        End If

        ' Ingrédients

        i = 0
        Dim chk As CheckBox
        Dim cnt As Integer = 0
        For i = 0 To gpbIngredients.Controls.Count - 1
            chk = gpbIngredients.Controls(i)
            If (chk.Checked) Then
                message = message & chk.Text & vbCrLf
                cnt = cnt + 1
            End If
        Next

        For Each item In clbSupplements.CheckedItems
            message = message & "Supplément " & item.ToString & vbCrLf
        Next

        If cnt = 0 Then
            MsgBox("Seulement de la croûte", Title:="Pauvre pizza !")
        Else
            MsgBox(message, Title:="Votre Pizza")
        End If


    End Sub

    Private Sub cmdInitialisation_Click(sender As Object, e As EventArgs) Handles cmdInitialisation.Click
        rdbPetite.Checked = True
        rdbFine.Checked = True
        Dim i As Integer
        Dim chk As CheckBox
        For i = 0 To gpbIngredients.Controls.Count - 1
            chk = gpbIngredients.Controls(i)
            chk.Checked = False
        Next
        rdbSurPlace.Checked = True
    End Sub

    Private Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Application.Exit()
    End Sub

    Private Sub gpbIngredients_Checkchanged(sender As Object, e As EventArgs) Handles chkFromage.CheckedChanged,
                                                                                      chkChampignon.CheckedChanged,
                                                                                      chkOignons.CheckedChanged,
                                                                                      chkOlives.CheckedChanged,
                                                                                      chkPoivrons.CheckedChanged,
                                                                                      chkTomates.CheckedChanged
        Dim chk As CheckBox
        Dim ingredients As String = ""
        Dim i As Integer
        Dim cnt As Integer = 0
        For i = 0 To gpbIngredients.Controls.Count - 1
            chk = gpbIngredients.Controls(i)
            If (chk.Checked) Then
                cnt += 1
            End If
            If cnt > 4 Then
                chk.Checked = False
                lblLimitIngr.Visible = True
            Else
                lblLimitIngr.Visible = False
            End If
        Next
    End Sub

End Class
