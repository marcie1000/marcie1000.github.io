﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClRestauObjet;
using ClClient;

namespace restaurantABaudouin
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu mnuEco = new Menu("Menu économique", "endives", "omelette", "tarte aux pommes", 1, 2, 1);

            Menu mnuClass = new Menu("Menu classique");
            mnuClass.setNomEntree("carottes rapées");
            mnuClass.setPrixEntree(2);
            mnuClass.setNomPlatPrincipal("Boeuf bourguignon");
            mnuClass.setPrixPlatPrincipal(4);
            mnuClass.setNomDessert("tarte aux citron");
            mnuClass.setPrixDessert(3);

            Menu mnuGastro = new Menu();
            mnuGastro.setLesNoms("Menu gastronomique", "truffe à la truffe", "truffe poêlée à la crème de truffe", "tarte à la truffe");
            mnuGastro.setLesPrix(25, 40, 35);

            Console.WriteLine(mnuEco.getNomMenu() + " : " + mnuEco.permetAffMenu());
            Console.WriteLine("TOTAL : " + mnuEco.prixMenu() + " EUR");

            Console.WriteLine(mnuClass.getNomMenu() + " : " + mnuClass.permetAffMenu());
            Console.WriteLine("TOTAL : " + mnuClass.prixMenu() + " EUR");

            Console.WriteLine(mnuGastro.getNomMenu() + " : " + mnuGastro.permetAffMenu());
            Console.WriteLine("TOTAL : " + mnuGastro.prixMenu() + " EUR");

            Client clt1 = new Client();
            Client clt2 = new Client();
            Client clt3 = new Client();
            Client clt4 = new Client();

            clt1.setNumeroClient(1);
            clt1.setNomClient("Dupont");
            clt1.setPrenomClient("Pierre");
            clt1.setAdresseClient("4 rue des panards");
            //clt1.mange(mnuGastro);
            clt1.rajouteMenu(mnuGastro);
            //Console.WriteLine("Client " + clt1.getNumeroClient() + " : " + 
            //    clt1.getPrenomClient() + " " + clt1.getNomClient() + ", " + 
            //    clt1.getAdresseClient() + ", mange " + clt1.getMenu().getNomMenu() +
            //    " Prix : " + clt1.getMenu().prixMenu() + " EUR.");
            Console.WriteLine("Client " + clt1.getNumeroClient() + " : " +
                clt1.getPrenomClient() + " " + clt1.getNomClient() + ", " +
                clt1.getAdresseClient() + ", mange " + clt1.getMenu(0).getNomMenu() +
                ", Prix : " + clt1.getMenu(0).prixMenu() + " EUR.");

            clt2.setNumeroClient(2);
            clt2.setNomClient("Wecker");
            clt2.setPrenomClient("Thierry");
            clt2.setAdresseClient("2 rue de l'Eglise Strasbourg");
            //clt2.mange(mnuEco);
            clt2.rajouteMenu(mnuEco);
            //Console.WriteLine("Client " + clt2.getNumeroClient() + " : " +
            //    clt2.getPrenomClient() + " " + clt2.getNomClient() + ", " +
            //    clt2.getAdresseClient() + ", mange " + clt2.getMenu().getNomMenu() + 
            //    " Prix : " + clt2.getMenu().prixMenu() + " EUR.");
            Console.WriteLine("Client " + clt2.getNumeroClient() + " : " +
                clt2.getPrenomClient() + " " + clt2.getNomClient() + ", " +
                clt2.getAdresseClient() + ", mange " + clt2.getMenu(0).getNomMenu() +
                ", Prix : " + clt2.getMenu(0).prixMenu() + " EUR.");

            clt3.setNumeroClient(3);
            clt3.setNomClient("Sayn");
            clt3.setPrenomClient("Mehmet");
            clt3.setAdresseClient("4 avenue de l'Opéra Mulhouse");
            //clt3.mange(mnuEco);
            clt3.rajouteMenu(mnuEco);
            //Console.WriteLine("Client " + clt3.getNumeroClient() + " : " +
            //    clt3.getPrenomClient() + " " + clt3.getNomClient() + ", " +
            //    clt3.getAdresseClient() + ", mange " + clt3.getMenu().getNomMenu() + 
            //    " Prix : " + clt3.getMenu().prixMenu() + " EUR.");
            Console.WriteLine("Client " + clt3.getNumeroClient() + " : " +
                clt3.getPrenomClient() + " " + clt3.getNomClient() + ", " +
                clt3.getAdresseClient() + ", mange " + clt3.getMenu(0).getNomMenu() +
                ", Prix : " + clt3.getMenu(0).prixMenu() + " EUR.");

            clt4.setNumeroClient(4);
            clt4.setNomClient("Demetz");
            clt4.setPrenomClient("Stéphanie");
            clt4.setAdresseClient("4 avenue de l'Opéra Mulhouse");
            //clt4.mange(mnuClass);
            clt4.rajouteMenu(mnuClass);
            //Console.WriteLine("Client " + clt4.getNumeroClient() + " : " +
            //    clt4.getPrenomClient() + " " + clt4.getNomClient() + ", " +
            //    clt4.getAdresseClient() + ", mange " + clt4.getMenu().getNomMenu() + 
            //    " Prix : " + clt4.getMenu().prixMenu() + " EUR.");
            Console.WriteLine("Client " + clt4.getNumeroClient() + " : " +
                clt4.getPrenomClient() + " " + clt4.getNomClient() + ", " +
                clt4.getAdresseClient() + ", mange " + clt4.getMenu(0).getNomMenu() +
                ", Prix : " + clt4.getMenu(0).prixMenu() + " EUR.");

            Client clt5 = new Client();

            clt5.setNumeroClient(5);
            clt5.setNomClient("Baudouin");
            clt5.setPrenomClient("Adélia");
            clt5.setAdresseClient("47 rue Schoch");
            clt5.rajouteMenu(mnuEco);
            clt5.rajouteMenu(mnuEco);
            clt5.rajouteMenu(mnuGastro);
            clt5.rajouteMenu(mnuGastro);
            clt5.rajouteMenu(mnuGastro);
            clt5.rajouteMenu(mnuGastro);
            clt5.rajouteMenu(mnuClass);
            Console.WriteLine("Client " + clt5.getNumeroClient() + " : " +
                clt5.getPrenomClient() + " " + clt5.getNomClient() + ", " +
                clt5.getAdresseClient() + ", Addition : " + clt5.addition(15) + " EUR.");

            ClientFidele clientfid1 = new ClientFidele(1000, "Clientfid", "Ahmet");
            Console.WriteLine(clientfid1.getNumeroClient() + clientfid1.getPrenomClient() + clientfid1.getNomClient());
            ClientFidele clientfid2 = new ClientFidele(2000, "BAUDOUIN", "Adélia");
            Console.WriteLine(clientfid2.getNumeroClient() + clientfid2.getPrenomClient() + clientfid2.getNomClient());

            Console.ReadKey();
        }
    }
}
