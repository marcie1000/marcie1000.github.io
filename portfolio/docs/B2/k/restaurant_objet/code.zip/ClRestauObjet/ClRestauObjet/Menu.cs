﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClRestauObjet
{
    public class Menu
    {
        private int prixEntree;
        private int prixPlatPrincipal;
        private int prixDessert;
        private string nomMenu;
        private string nomEntree;
        private string nomPlatPrincipal;
        private string nomDessert;

        // Constructeurs
        public Menu()
        {
            prixEntree = 0;
            prixPlatPrincipal = 0;
            prixDessert = 0;
            nomMenu = "Baudouin";
            nomEntree = "Baudouin";
            nomPlatPrincipal = "Baudouin";
            nomDessert = "Baudouin";
        }

        public Menu(string nomMe)
        {
            prixEntree = 0;
            prixPlatPrincipal = 0;
            prixDessert = 0;
            nomMenu = nomMe;
            nomEntree = "Baudouin";
            nomPlatPrincipal = "Baudouin";
            nomDessert = "Baudouin";
        }

        public Menu(string nomMe, string nomEn, string nomPP, string nomDe, int pxEn, int pxPP, int pxDe)
        {
            prixEntree = pxEn;
            prixPlatPrincipal = pxPP;
            prixDessert = pxDe;
            nomMenu = nomMe;
            nomEntree = nomEn;
            nomPlatPrincipal = nomPP;
            nomDessert = nomDe;
        }

        // nomMenu
        public void setNomMenu(string nomMe)
        {
            nomMenu = nomMe;
        }

        public string getNomMenu()
        {
            return nomMenu;
        }

        // nomEntree
        public void setNomEntree(string nomEn)
        {
            nomEntree = nomEn;
        }

        public string getNomEntree()
        {
            return nomEntree;
        }

        // nomPlatPrincipal
        public void setNomPlatPrincipal(string nomPP)
        {
            nomPlatPrincipal = nomPP;
        }

        public string getNomPlatPrincipal()
        {
            return nomPlatPrincipal;
        }

        // nomDessert
        public void setNomDessert(string nomDe)
        {
            nomDessert = nomDe;
        }

        public string getNomDessert()
        {
            return nomDessert;
        }

        //prixEntree
        public void setPrixEntree(int pxEn)
        {
            prixEntree = pxEn;
        }

        //prixPlatPrincipal
        public void setPrixPlatPrincipal(int pxPP)
        {
            prixPlatPrincipal = pxPP;
        }

        // prixDessert
        public void setPrixDessert(int pxDe)
        {
            prixDessert = pxDe;
        }

        // ======
        public void setLesPrix(int pxEn, int pxPP, int pxDe)
        {
            prixEntree = pxEn;
            prixPlatPrincipal = pxPP;
            prixDessert = pxDe;
        }

        public void setLesNoms(string nomMe, string nomEn, string nomPP, string nomDe)
        {
            nomMenu = nomMe;
            nomEntree = nomEn;
            nomPlatPrincipal = nomPP;
            nomDessert = nomDe;
        }

        public void setLesNoms(string nomEn, string nomPP, string nomDe)
        {
            nomEntree = nomEn;
            nomPlatPrincipal = nomPP;
            nomDessert = nomDe;
        }

        public string permetAffMenu()
        {
            return nomEntree + ", " + nomPlatPrincipal + ", " + nomDessert;
        }

        public int prixMenu()
        {
            return prixEntree + prixPlatPrincipal + prixDessert;
        }
    }
}
