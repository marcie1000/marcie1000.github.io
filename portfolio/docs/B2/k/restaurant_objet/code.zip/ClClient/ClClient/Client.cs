﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClRestauObjet;

namespace ClClient
{
    public class Client
    {
        private int numeroClient;
        private string nomClient;
        private string prenomClient;
        private string adresseClient;
        //private Menu menu;
        private List<Menu> tabMenu = new List<Menu>();
        private int nbreMenu;

        public void rajouteMenu(Menu unMenu)
        {
            //if(nbreMenu >= 9)
            //{
            //    throw new Exception("Le nombre maximal de menu est atteint !");
            //}
            //else
            //{
            //    tabMenu[nbreMenu] = unMenu;
            //    nbreMenu++;
            //}
            tabMenu.Add(unMenu);
            nbreMenu++;
        }

        //public void mange(Menu unMenu)
        //{
        //    menu = unMenu;
        //}

        //public Menu getMenu()
        //{
        //    return menu;
        //}
        public Menu getMenu(int id)
        {
            return tabMenu[id];
        }

        public Client()
        {
            //tabMenu = new Menu[10];
            nbreMenu = 0;
        }

        public Client(int numCli)
        {
            //tabMenu = new Menu[10];
            nbreMenu = 0;
            numeroClient = numCli;
        }

        public Client(int numCli, string nomCli, string prenomCli)
        {
            //tabMenu = new Menu[10];
            nbreMenu = 0;
            numeroClient = numCli;
            nomClient = nomCli;
            prenomClient = prenomCli;
        }

        public int getNumeroClient()
        {
            return numeroClient;
        }

        public void setNumeroClient(int numCli)
        {
            numeroClient = numCli;
        }

        public string getNomClient()
        {
            return nomClient;
        }

        public void setNomClient(string nomCli)
        {
            nomClient = nomCli;
        }

        public string getPrenomClient()
        {
            return prenomClient;
        }

        public void setPrenomClient(string prenomCli)
        {
            prenomClient = prenomCli;
        }

        public string getAdresseClient()
        {
            return adresseClient;
        }

        public void setAdresseClient(string adresseCli)
        {
            adresseClient = adresseCli;
        }

        public double addition()
        {
            double add = 0;
            for (int i = 0; i < nbreMenu; i++)
            {
                add += (double)getMenu(i).prixMenu();
            }
            return add;
        }

        public double addition(int reduc)
        {
            double add = addition();
            add -= add * (double)reduc / 100.0;
            return add;
        }
    }

    public class ClientFidele : Client
    {
        public ClientFidele() : base()
        {

        }
        
        private int remise;

        public ClientFidele(int numClient) : base(numClient)
        {

        }

        public ClientFidele(int numCli, string nomCli, string prenomCli) : base(numCli, nomCli, prenomCli)
        {

        }

        public ClientFidele(int numClient, int laRemise)
        {
            setNumeroClient(numClient);
            remise = laRemise;
        }

        public new double addition()
        {
            Console.WriteLine("L'addition sans la remise : " + base.addition());
            return base.addition(10);
        }

        public new double addition(int supplementaire)
        {
            Console.WriteLine("L'addition sans la remise : " + base.addition());
            return base.addition(supplementaire + 10);
        }

        public double additionRemiseIntegree()
        {
            Console.WriteLine("L'addition sans la remise : " + base.addition());
            return base.addition(remise);
        }
    }
}
